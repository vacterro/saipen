"""One canonical release-contract inventory (T-994).

Both the release planner/executor and validate.py must agree on which files
are release metadata. This module owns that definition so the two consumers
can never drift apart.

This module is READ-ONLY, not side-effect-free: it performs no writes, no git
calls and no logging, but ``version_badges(path)`` reads a file to report its
badges. Callers own their reads; the module only promises never to mutate.
"""

from __future__ import annotations

import re
import subprocess
from pathlib import Path


def locale_readme_paths(kitchen_dir: Path) -> list[Path]:
    """Return every mechanically named locale README, including missing ones.

    Mirrors validate.py's original ``locale_readme_paths`` -- this is now the
    single source of truth.
    """
    kitchen_dir = Path(kitchen_dir)
    if not kitchen_dir.is_dir():
        return []
    return [
        directory / f"README_{directory.name.upper()}.md"
        for directory in sorted(kitchen_dir.iterdir())
        if directory.is_dir()
    ]


def version_metadata_paths(root: Path) -> list[Path]:
    """The release surface: VERSION, README.md, CHANGELOG.md, the three root
    README mirrors (README.ee.md, README.ded.md, README.ja.md), the portable
    project-identity carrier (`.saipen/IDENTITY.md`) and every mechanically
    mirrored locale README under the translation kitchen.

    The identity carrier is part of the release surface BY CONTRACT (T-1003
    carrier-loss wave): the portable lineage must be tracked and clone-stable,
    so a full release stages and commits it -- a fresh clone then exposes the
    same lineage. Both the release executor and the validator use this exact
    set. All returned paths are repository-relative, so callers can feed them
    directly to `git add --` and compare them against `git diff --cached`
    output.

    T-1617: a locale README that Git ignores is NOT on this surface. The whole
    kitchen is ignored by `.gitignore` (added at v8.1.0 to drop sandbox WIP),
    so enumerating the kitchen unconditionally made the ship gate demand files
    that `git add` refuses without `-f` -- the gate was unsatisfiable by
    construction, and only stayed silent while no translation run happened to
    leave locale READMEs behind. The release surface is by definition the set
    of paths that SURVIVE a fresh clone; a path the repository ignores cannot
    be part of it. The tracked root mirrors (README.ee/ded/ja.md) remain the
    published translations and are still listed unconditionally above.
    """
    root = Path(root)
    kitchen = root / ".saipen" / "saitranslate" / "kitchen"
    paths = [
        Path("VERSION"),
        Path("README.md"),
        Path("README.ee.md"),
        Path("README.ded.md"),
        Path("README.ja.md"),
        Path("CHANGELOG.md"),
        Path(".saipen/IDENTITY.md"),
    ]
    for readme in locale_readme_paths(kitchen):
        try:
            relative = readme.relative_to(root)
        except ValueError:
            # A kitchen outside the repository root is not a release surface.
            continue
        # Ask Git, not a second copy of the ignore rules: only a path the
        # repository would actually carry into a clone belongs here.
        if _git_ignored(root, relative):
            continue
        paths.append(relative)
    return paths


def _git_ignored(root: Path, relative: Path) -> bool:
    """True when `git check-ignore` refuses `relative` in this repository.

    Fails CLOSED in the safe direction: an unrunnable or absent Git answers
    False, so a path is kept on the release surface exactly as it was before
    this filter existed. Only a positive ignore answer removes it, which is
    the case the v8.1.0 kitchen rule creates.
    """
    try:
        result = subprocess.run(
            ["git", "-C", str(root), "check-ignore", "-q", "--", str(relative)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
    except OSError:
        return False
    return result.returncode == 0


def source_authority_paths(root: Path) -> list[Path]:
    """Return the complete distributable source-authority transition surface.

    Source receipts are release authority, not runtime cache.  Enumerating the
    fixed owned trees here makes the release planner, stager and ship validator
    agree on the exact bytes that may survive a fresh clone. Quarantined exact
    bodies live outside both owned trees; their digest-bound distribution
    records remain below ``intake/`` and therefore stay on this surface.
    """
    root = Path(root)
    paths: set[Path] = set()
    # A close is a move: tracked active carriers disappear while archive
    # carriers appear.  Existing-file enumeration misses those deletions and
    # lets a release commit only half the authority transition.  Git's one
    # bounded inventory query supplies the missing historical members.
    try:
        result = subprocess.run(
            ["git", "-C", str(root), "ls-files", "-z", "--",
             ".saipen/intake", ".saipen/archive/source"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )
        if result.returncode == 0:
            for raw in result.stdout.split(b"\0"):
                if raw:
                    paths.add(Path(raw.decode("utf-8")))
    except (OSError, UnicodeDecodeError):
        # No-Git projects still get their current canonical surface.  A Git
        # release cannot silently claim deletion coverage without this query;
        # the ship gate's tracked-path check will refuse that case.
        pass
    for base_rel in (Path(".saipen/intake"), Path(".saipen/archive/source")):
        base = root / base_rel
        if not base.is_dir():
            continue
        for candidate in base.rglob("*"):
            if candidate.is_file() and not candidate.is_symlink():
                try:
                    paths.add(candidate.relative_to(root))
                except ValueError:
                    continue
    return sorted(paths, key=lambda path: path.as_posix())


def release_metadata_paths(
    root: Path, source_paths: list[Path] | None = None
) -> list[Path]:
    """Exact clone-stable release authority and version metadata surface."""
    return [
        *version_metadata_paths(root),
        Path(".gitattributes"),
        *(source_paths if source_paths is not None else source_authority_paths(root)),
    ]


#: A release version as this repository family writes it: three numeric
#: components plus the bare pre-release suffix the project actually ships
#: (``0.0.2a3``). The suffix sits INSIDE the bold, so a pattern that stops
#: at the third digit can never match a badge this project writes, which
#: made the release parity gate unsatisfiable for every version in its own
#: history (T-131). The suffix class stops at whitespace and the pattern is
#: anchored by the bold delimiters, so it is safe to read the hyphen/plus
#: forms here (`1.2.3-rc.1`, `2.0.0+build.5`) that freshness.VERSION_TOKEN_RE
#: deliberately refuses, because there a greedy tail would swallow the rest
#: of a wheel filename and hide a real content change behind a version prefix.
RELEASE_VERSION_CORE = r"\d+\.\d+\.\d+(?:[-+]?[0-9A-Za-z][0-9A-Za-z.+-]*)?"
_VERSION_BADGE_RE = re.compile(r"\*\*v" + RELEASE_VERSION_CORE + r"\*\*")


def version_badges(path: Path) -> list[str]:
    """Return all ``**vX.Y.Z**`` badges found in *path*."""
    text = Path(path).read_text(encoding="utf-8-sig")
    return _VERSION_BADGE_RE.findall(text)
